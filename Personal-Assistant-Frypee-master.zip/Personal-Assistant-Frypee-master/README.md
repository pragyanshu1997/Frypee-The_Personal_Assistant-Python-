# Personal-Assistant-Frypee
Frypee is a sort of personal assistant(actually a prototype).It is made in python and uses google speech recognition API to convert speech to text. It uses urllib and BeautifulSoup for scraping the web and a json parser to explore the data received.
You can search for meaning of any word, temperature of any city, your current location, current time, etc.

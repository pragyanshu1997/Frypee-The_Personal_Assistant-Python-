#import os
import json
import speaking
import microphone
import urllib2
import BeautifulSoup





'''if __name__=="__main__":
    maps("Rajiv Chowk")'''
